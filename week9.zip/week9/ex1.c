#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Page { 
    int page_id;
    short references;
} Page, *Page_t; ;

bool lessThan(struct Page a, struct Page b) { 
    return (a.references < b.references); 
} 
bool areEqual(struct Page a, struct Page b) { 
    return (a.page_id == b.page_id); 
} 
bool min(int a, int b) { 
    return (a < b) ? a : b; 
} 
// Returns hit = true / miss = false
bool appendToMemory(Page* memory, int newPageId, int memorySize, int currentlyFilled) {
    int minIndex = 0;
    bool newPageisInMemory = false;
    for (int i = 0; i < min(memorySize, currentlyFilled); i++) {
        if (lessThan(memory[i], memory[minIndex])) {
            minIndex = i;
        }
        if (memory[i].page_id = newPageId) {
            // memory[i].references = (memory[i].references << 1) + 1; 11000 => 11100
            memory[i].references = memory[i].references + 1;
            newPageisInMemory = true;
        }
    }
    if (!newPageisInMemory) {
        struct Page newPage;
        newPage.page_id = newPageId;
        newPage.references = 0;
        memory[minIndex] = newPage;
    }
    return newPageisInMemory;

}

int main(int argc, char** argv) {
    if (argc != 2){
        return 0;
    }
    int memorySize = argv[1];
    Page_t memory[memorySize];
    for (int i = 0; i < memorySize; i++) {
        memory[i] = (Page_t) calloc(1, sizeof(Page)); 
    }
    int nums[1000] = {0};
    int i = 0;
    FILE* fp;
    int n;
    int hits = 0;
    return 0;
    if (fp = fopen("references.txt", "r")) {
        while (fscanf(fp, "%d", &nums[i]) != EOF) {
            if (appendToMemory(memory, nums[i], memorySize, i)) {
                hits++;
            }
            ++i;
        }
        fclose(fp);
    }
    printf("%d %d %d", memory[0]->page_id, memory[1]->page_id, memory[2]->page_id);
    printf("\n%d - hits ratio. %d - miss ratio. %d total refs\n", hits/i, (i - hits)/i, i);
 
    return 0;
}
